import React from 'react';
import { 
  TrendingUp, 
  MessageSquare, 
  Settings, 
  Users, 
  BarChart3, 
  Camera 
} from 'lucide-react';

const Servizi = () => {
  const servizi = [
    {
      icon: TrendingUp,
      title: "Ottimizzazione annuncio & pricing",
      description: "Testi efficaci, analisi del mercato, regole di prezzo dinamiche",
      color: "blue"
    },
    {
      icon: MessageSquare,
      title: "Comunicazione con gli ospiti",
      description: "Messaggi automatici e personalizzati, risposte rapide",
      color: "green"
    },
    {
      icon: Settings,
      title: "Gestione operativa",
      description: "Coordinamento pulizie/check-in/out, manutenzioni leggere",
      color: "purple"
    },
    {
      icon: Users,
      title: "CRM ospiti",
      description: "Anagrafica digitale degli ospiti con cronologia soggiorni e note",
      color: "teal"
    },
    {
      icon: BarChart3,
      title: "Reportistica e strategia",
      description: "Report mensile + call strategica da 30 minuti per analizzare performance",
      color: "orange"
    },
    {
      icon: Camera,
      title: "Servizi extra (on demand)",
      description: "Shooting fotografico, welcome pack, setup annuncio, restyling profilo",
      color: "red"
    }
  ];

  const colorClasses = {
    blue: "from-blue-500 to-blue-600",
    green: "from-green-500 to-green-600",
    purple: "from-purple-500 to-purple-600",
    teal: "from-teal-500 to-teal-600",
    orange: "from-orange-500 to-orange-600",
    red: "from-red-500 to-red-600"
  };

  return (
    <section id="servizi" className="py-20 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-6">
            Servizi offerti
          </h2>
          <div className="w-20 h-1 bg-blue-600 mx-auto mb-8"></div>
          <p className="text-lg text-gray-600 max-w-3xl mx-auto">
            Soluzioni complete per gestire la tua casa vacanza in modo professionale e redditizio
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {servizi.map((servizio, index) => {
            const Icon = servizio.icon;
            return (
              <div
                key={index}
                className="bg-white rounded-lg shadow-md hover:shadow-lg transition-shadow p-6 group"
              >
                <div className={`w-16 h-16 bg-gradient-to-r ${colorClasses[servizio.color as keyof typeof colorClasses]} rounded-lg flex items-center justify-center mb-4 group-hover:scale-110 transition-transform`}>
                  <Icon className="text-white" size={28} />
                </div>
                <h3 className="text-xl font-semibold text-gray-900 mb-3">
                  {servizio.title}
                </h3>
                <p className="text-gray-600 leading-relaxed">
                  {servizio.description}
                </p>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
};

export default Servizi;