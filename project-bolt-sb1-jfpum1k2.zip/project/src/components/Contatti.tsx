import React, { useState } from 'react';
import { MessageCircle, Mail, Phone, Send } from 'lucide-react';

const Contatti = () => {
  const [formData, setFormData] = useState({
    nome: '',
    email: '',
    messaggio: ''
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Qui potresti integrare con un servizio di form handling
    const whatsappMessage = `Ciao, sono ${formData.nome}. ${formData.messaggio}. La mia email è: ${formData.email}`;
    const whatsappUrl = `https://wa.me/39TUONUMERO?text=${encodeURIComponent(whatsappMessage)}`;
    window.open(whatsappUrl, '_blank');
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    setFormData(prev => ({
      ...prev,
      [e.target.name]: e.target.value
    }));
  };

  return (
    <section id="contatti" className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-6">
            Contatti
          </h2>
          <div className="w-20 h-1 bg-blue-600 mx-auto mb-8"></div>
          <p className="text-lg text-gray-600 max-w-3xl mx-auto">
            Pronto a ottimizzare la gestione della tua casa vacanza? Contattaci per una consulenza gratuita!
          </p>
        </div>

        <div className="grid md:grid-cols-2 gap-12">
          {/* Modulo di contatto */}
          <div className="bg-gray-50 rounded-lg p-8">
            <h3 className="text-2xl font-bold text-gray-900 mb-6">Invia un messaggio</h3>
            <form onSubmit={handleSubmit} className="space-y-6">
              <div>
                <label htmlFor="nome" className="block text-sm font-medium text-gray-700 mb-2">
                  Nome *
                </label>
                <input
                  type="text"
                  id="nome"
                  name="nome"
                  required
                  value={formData.nome}
                  onChange={handleChange}
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  placeholder="Il tuo nome"
                />
              </div>

              <div>
                <label htmlFor="email" className="block text-sm font-medium text-gray-700 mb-2">
                  Email *
                </label>
                <input
                  type="email"
                  id="email"
                  name="email"
                  required
                  value={formData.email}
                  onChange={handleChange}
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  placeholder="la-tua-email@esempio.com"
                />
              </div>

              <div>
                <label htmlFor="messaggio" className="block text-sm font-medium text-gray-700 mb-2">
                  Messaggio *
                </label>
                <textarea
                  id="messaggio"
                  name="messaggio"
                  required
                  rows={4}
                  value={formData.messaggio}
                  onChange={handleChange}
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  placeholder="Raccontaci delle tue case vacanza e di cosa hai bisogno..."
                />
              </div>

              <button
                type="submit"
                className="w-full bg-blue-600 hover:bg-blue-700 text-white py-3 px-6 rounded-lg font-semibold flex items-center justify-center space-x-2 transition-colors"
              >
                <Send size={20} />
                <span>Invia messaggio</span>
              </button>
            </form>
          </div>

          {/* Contatti diretti */}
          <div className="space-y-8">
            <div>
              <h3 className="text-2xl font-bold text-gray-900 mb-6">Contatti diretti</h3>
              <p className="text-gray-600 mb-8">
                Preferisci un contatto diretto? Ecco come raggiungerci immediatamente:
              </p>
            </div>

            <div className="space-y-6">
              <a
                href="https://wa.me/39TUONUMERO?text=Ciao%2C%20vorrei%20informazioni%20su%20AirBrain"
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center p-6 bg-green-50 rounded-lg hover:bg-green-100 transition-colors group"
              >
                <div className="bg-green-100 p-3 rounded-full mr-4 group-hover:bg-green-200 transition-colors">
                  <MessageCircle className="text-green-600" size={24} />
                </div>
                <div>
                  <h4 className="text-lg font-semibold text-gray-900">WhatsApp</h4>
                  <p className="text-gray-600">Risposta immediata</p>
                </div>
              </a>

              <div className="flex items-center p-6 bg-blue-50 rounded-lg">
                <div className="bg-blue-100 p-3 rounded-full mr-4">
                  <Mail className="text-blue-600" size={24} />
                </div>
                <div>
                  <h4 className="text-lg font-semibold text-gray-900">Email</h4>
                  <p className="text-gray-600">info@airbrain.it</p>
                </div>
              </div>

              <div className="flex items-center p-6 bg-gray-50 rounded-lg">
                <div className="bg-gray-100 p-3 rounded-full mr-4">
                  <Phone className="text-gray-600" size={24} />
                </div>
                <div>
                  <h4 className="text-lg font-semibold text-gray-900">Telefono</h4>
                  <p className="text-gray-600">+39 TUO NUMERO</p>
                </div>
              </div>
            </div>

            <div className="bg-teal-50 p-6 rounded-lg">
              <h4 className="text-lg font-semibold text-gray-900 mb-2">Consulenza gratuita</h4>
              <p className="text-gray-600 mb-4">
                Offriamo una prima consulenza gratuita di 30 minuti per valutare insieme le tue esigenze.
              </p>
              <a
                href="https://wa.me/39TUONUMERO?text=Ciao%2C%20vorrei%20prenotare%20una%20consulenza%20gratuita"
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center bg-teal-600 hover:bg-teal-700 text-white px-4 py-2 rounded-lg font-semibold transition-colors"
              >
                Prenota ora
              </a>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Contatti;