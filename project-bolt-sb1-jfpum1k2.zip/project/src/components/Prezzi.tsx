import React from 'react';
import { Check, Star, Zap, Crown } from 'lucide-react';

const Prezzi = () => {
  const pacchetti = [
    {
      name: "Base",
      price: "59",
      icon: Star,
      description: "Perfetto per iniziare",
      features: [
        "Pricing dinamico",
        "CRM ospiti",
        "Report mensile",
        "Supporto email"
      ],
      color: "blue",
      popular: false
    },
    {
      name: "Smart",
      price: "89",
      icon: Zap,
      description: "Il più scelto",
      features: [
        "Tutto di Base",
        "Comunicazione ospiti",
        "Gestione pulizie",
        "Check-in/out coordinato",
        "Supporto prioritario"
      ],
      color: "teal",
      popular: true
    },
    {
      name: "Premium",
      price: "129",
      icon: Crown,
      description: "Servizio completo",
      features: [
        "Tutto di Smart",
        "Manutenzioni leggere",
        "2 call strategiche/mese",
        "Supporto prioritario",
        "Servizi extra scontati"
      ],
      color: "orange",
      popular: false
    }
  ];

  const colorClasses = {
    blue: {
      bg: "bg-blue-50",
      border: "border-blue-200",
      text: "text-blue-600",
      button: "bg-blue-600 hover:bg-blue-700",
      icon: "bg-blue-100 text-blue-600"
    },
    teal: {
      bg: "bg-teal-50",
      border: "border-teal-200",
      text: "text-teal-600",
      button: "bg-teal-600 hover:bg-teal-700",
      icon: "bg-teal-100 text-teal-600"
    },
    orange: {
      bg: "bg-orange-50",
      border: "border-orange-200",
      text: "text-orange-600",
      button: "bg-orange-600 hover:bg-orange-700",
      icon: "bg-orange-100 text-orange-600"
    }
  };

  return (
    <section id="prezzi" className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-6">
            Pacchetti e prezzi
          </h2>
          <div className="w-20 h-1 bg-blue-600 mx-auto mb-8"></div>
          <p className="text-lg text-gray-600 max-w-3xl mx-auto">
            Scegli il pacchetto più adatto alle tue esigenze. Tutti i prezzi sono mensili e senza vincoli.
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-8">
          {pacchetti.map((pacchetto, index) => {
            const Icon = pacchetto.icon;
            const colors = colorClasses[pacchetto.color as keyof typeof colorClasses];
            
            return (
              <div
                key={index}
                className={`relative rounded-lg border-2 ${colors.border} ${colors.bg} p-8 ${
                  pacchetto.popular ? 'transform scale-105 shadow-xl' : 'shadow-md'
                }`}
              >
                {pacchetto.popular && (
                  <div className="absolute -top-4 left-1/2 transform -translate-x-1/2">
                    <span className="bg-teal-500 text-white px-4 py-1 rounded-full text-sm font-semibold">
                      Più popolare
                    </span>
                  </div>
                )}

                <div className="text-center mb-6">
                  <div className={`w-16 h-16 ${colors.icon} rounded-full flex items-center justify-center mx-auto mb-4`}>
                    <Icon size={28} />
                  </div>
                  <h3 className="text-2xl font-bold text-gray-900 mb-2">{pacchetto.name}</h3>
                  <p className="text-gray-600 mb-4">{pacchetto.description}</p>
                  <div className="flex items-center justify-center mb-4">
                    <span className="text-4xl font-bold text-gray-900">{pacchetto.price}€</span>
                    <span className="text-gray-600 ml-2">/mese</span>
                  </div>
                </div>

                <ul className="space-y-3 mb-8">
                  {pacchetto.features.map((feature, featureIndex) => (
                    <li key={featureIndex} className="flex items-center">
                      <Check className="text-green-500 mr-3 flex-shrink-0" size={20} />
                      <span className="text-gray-700">{feature}</span>
                    </li>
                  ))}
                </ul>

                <a
                  href="https://wa.me/39TUONUMERO?text=Ciao%2C%20sono%20interessato%20al%20pacchetto%20AirBrain"
                  target="_blank"
                  rel="noopener noreferrer"
                  className={`block w-full ${colors.button} text-white py-3 px-6 rounded-lg font-semibold text-center transition-colors hover:shadow-lg`}
                >
                  Inizia ora
                </a>
              </div>
            );
          })}
        </div>

        <div className="mt-12 text-center">
          <p className="text-gray-600 mb-4">
            Hai domande sui nostri pacchetti? Parliamone!
          </p>
          <a
            href="https://wa.me/39TUONUMERO?text=Ciao%2C%20vorrei%20maggiori%20informazioni%20sui%20pacchetti%20AirBrain"
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center bg-green-500 hover:bg-green-600 text-white px-6 py-3 rounded-lg font-semibold transition-colors"
          >
            Confronta i pacchetti su WhatsApp
          </a>
        </div>
      </div>
    </section>
  );
};

export default Prezzi;