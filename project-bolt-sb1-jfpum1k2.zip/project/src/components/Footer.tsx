import React from 'react';
import { MessageCircle, Mail, Phone, Brain } from 'lucide-react';

const Footer = () => {
  return (
    <footer className="bg-gray-900 text-white py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid md:grid-cols-4 gap-8">
          {/* Brand */}
          <div className="col-span-2">
            <div className="flex items-center mb-4">
              <Brain className="text-blue-400 mr-2" size={28} />
              <h3 className="text-2xl font-bold">AirBrain</h3>
            </div>
            <p className="text-gray-400 mb-4 max-w-md">
              Gestione smart per affitti brevi. Massimizza i guadagni del tuo appartamento con meno stress e più organizzazione.
            </p>
            <div className="flex space-x-4">
              <a
                href="https://wa.me/39TUONUMERO"
                target="_blank"
                rel="noopener noreferrer"
                className="bg-green-600 hover:bg-green-700 p-2 rounded-lg transition-colors"
              >
                <MessageCircle size={20} />
              </a>
              <a
                href="mailto:info@airbrain.it"
                className="bg-blue-600 hover:bg-blue-700 p-2 rounded-lg transition-colors"
              >
                <Mail size={20} />
              </a>
              <a
                href="tel:+39TUONUMERO"
                className="bg-gray-600 hover:bg-gray-700 p-2 rounded-lg transition-colors"
              >
                <Phone size={20} />
              </a>
            </div>
          </div>

          {/* Servizi */}
          <div>
            <h4 className="text-lg font-semibold mb-4">Servizi</h4>
            <ul className="space-y-2 text-gray-400">
              <li><a href="#servizi" className="hover:text-white transition-colors">Ottimizzazione pricing</a></li>
              <li><a href="#servizi" className="hover:text-white transition-colors">Comunicazione ospiti</a></li>
              <li><a href="#servizi" className="hover:text-white transition-colors">Gestione operativa</a></li>
              <li><a href="#servizi" className="hover:text-white transition-colors">CRM ospiti</a></li>
              <li><a href="#servizi" className="hover:text-white transition-colors">Reportistica</a></li>
            </ul>
          </div>

          {/* Contatti */}
          <div>
            <h4 className="text-lg font-semibold mb-4">Contatti</h4>
            <ul className="space-y-2 text-gray-400">
              <li>
                <a href="https://wa.me/39TUONUMERO" target="_blank" rel="noopener noreferrer" className="hover:text-white transition-colors">
                  WhatsApp
                </a>
              </li>
              <li>
                <a href="mailto:info@airbrain.it" className="hover:text-white transition-colors">
                  info@airbrain.it
                </a>
              </li>
              <li>
                <a href="tel:+39TUONUMERO" className="hover:text-white transition-colors">
                  +39 TUO NUMERO
                </a>
              </li>
            </ul>
          </div>
        </div>

        <div className="border-t border-gray-800 mt-8 pt-8 text-center">
          <p className="text-gray-400">
            © 2025 AirBrain. Tutti i diritti riservati.
          </p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;