import React from 'react';
import { GraduationCap, Briefcase, Brain, Award } from 'lucide-react';

const ChiSono = () => {
  const qualifiche = [
    {
      icon: GraduationCap,
      title: "Ingegnere Gestionale",
      description: "Formazione tecnica e manageriale"
    },
    {
      icon: Briefcase,
      title: "Consulenza & PM",
      description: "Esperienza in project management"
    },
    {
      icon: Brain,
      title: "Digital Transformation",
      description: "Specializzazione in innovazione"
    },
    {
      icon: Award,
      title: "Executive MBA",
      description: "In completamento"
    }
  ];

  return (
    <section className="py-20 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-6">
            Chi sono
          </h2>
          <div className="w-20 h-1 bg-blue-600 mx-auto mb-8"></div>
        </div>

        <div className="grid md:grid-cols-2 gap-12 items-center">
          <div className="order-2 md:order-1">
            <div className="bg-white rounded-lg shadow-md p-8">
              <div className="flex items-center mb-6">
                <div className="w-20 h-20 bg-gradient-to-r from-blue-500 to-teal-500 rounded-full flex items-center justify-center text-white text-2xl font-bold mr-6">
                  VT
                </div>
                <div>
                  <h3 className="text-2xl font-bold text-gray-900">Vittorio Terreo</h3>
                  <p className="text-gray-600">Fondatore AirBrain</p>
                </div>
              </div>
              
              <p className="text-gray-700 leading-relaxed mb-6">
                Mi chiamo <strong>Vittorio Terreo</strong>, sono un ingegnere gestionale con esperienza in consulenza, project management e digital transformation. Sto completando un Executive MBA e ho creato AirBrain per portare metodo, visione e organizzazione nel mondo degli affitti brevi.
              </p>
              
              <p className="text-gray-700 leading-relaxed">
                La mia missione è aiutare i piccoli proprietari a trasformare la gestione delle loro case vacanza da un'attività stressante a un business organizzato e redditizio.
              </p>
            </div>
          </div>

          <div className="order-1 md:order-2">
            <div className="grid grid-cols-2 gap-4">
              {qualifiche.map((qualifica, index) => {
                const Icon = qualifica.icon;
                return (
                  <div
                    key={index}
                    className="bg-white rounded-lg shadow-md p-6 text-center hover:shadow-lg transition-shadow"
                  >
                    <div className="bg-blue-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                      <Icon className="text-blue-600" size={28} />
                    </div>
                    <h4 className="text-lg font-semibold text-gray-900 mb-2">
                      {qualifica.title}
                    </h4>
                    <p className="text-gray-600 text-sm">
                      {qualifica.description}
                    </p>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default ChiSono;