import React from 'react';
import { Target, Users, Zap } from 'lucide-react';

const ChiSiamo = () => {
  return (
    <section id="chi-siamo" className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-6">
            Chi siamo
          </h2>
          <div className="w-20 h-1 bg-blue-600 mx-auto mb-8"></div>
        </div>

        <div className="grid md:grid-cols-2 gap-12 items-center">
          <div>
            <p className="text-lg text-gray-600 mb-6 leading-relaxed">
              <strong className="text-blue-600">AirBrain</strong> è un servizio innovativo nato per aiutare i piccoli proprietari (1–3 appartamenti) che vogliono gestire le proprie case vacanza in modo professionale, ma senza dover affidarsi a grandi agenzie o strumenti complessi.
            </p>
            <p className="text-lg text-gray-600 mb-6 leading-relaxed">
              Offriamo soluzioni modulari, concrete e flessibili per ottimizzare guadagni, semplificare la gestione quotidiana e migliorare l'esperienza degli ospiti.
            </p>
            <p className="text-lg text-gray-600 mb-8 leading-relaxed">
              Lavoriamo al tuo fianco, come un <strong className="text-blue-600">cervello operativo esterno</strong>, ma sempre con te.
            </p>
          </div>

          <div className="grid gap-6">
            <div className="bg-blue-50 p-6 rounded-lg">
              <div className="flex items-center mb-4">
                <div className="bg-blue-100 p-2 rounded-full mr-4">
                  <Target className="text-blue-600" size={24} />
                </div>
                <h3 className="text-xl font-semibold text-gray-900">Soluzioni mirate</h3>
              </div>
              <p className="text-gray-600">
                Servizi progettati specificamente per piccoli proprietari che vogliono professionalità senza complessità.
              </p>
            </div>

            <div className="bg-teal-50 p-6 rounded-lg">
              <div className="flex items-center mb-4">
                <div className="bg-teal-100 p-2 rounded-full mr-4">
                  <Users className="text-teal-600" size={24} />
                </div>
                <h3 className="text-xl font-semibold text-gray-900">Supporto personalizzato</h3>
              </div>
              <p className="text-gray-600">
                Un approccio umano e diretto, con consulenza strategica e supporto operativo continuo.
              </p>
            </div>

            <div className="bg-orange-50 p-6 rounded-lg">
              <div className="flex items-center mb-4">
                <div className="bg-orange-100 p-2 rounded-full mr-4">
                  <Zap className="text-orange-600" size={24} />
                </div>
                <h3 className="text-xl font-semibold text-gray-900">Efficienza operativa</h3>
              </div>
              <p className="text-gray-600">
                Ottimizzazione dei processi per massimizzare i guadagni riducendo tempo e stress.
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default ChiSiamo;