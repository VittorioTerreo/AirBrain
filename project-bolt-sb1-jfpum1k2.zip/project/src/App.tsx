import React from 'react';
import Header from './components/Header';
import Hero from './components/Hero';
import ChiSiamo from './components/ChiSiamo';
import Servizi from './components/Servizi';
import Prezzi from './components/Prezzi';
import ChiSono from './components/ChiSono';
import Contatti from './components/Contatti';
import Footer from './components/Footer';

function App() {
  return (
    <div className="min-h-screen bg-white">
      <Header />
      <Hero />
      <ChiSiamo />
      <Servizi />
      <Prezzi />
      <ChiSono />
      <Contatti />
      <Footer />
    </div>
  );
}

export default App;